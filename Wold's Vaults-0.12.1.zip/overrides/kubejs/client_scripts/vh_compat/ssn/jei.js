// onEvent('jei.hide.items', event => {
//     Ingredient.of('@storagenetwork').itemIds.forEach(id => {
//         event.hide(`${id}`)
//     })
// })