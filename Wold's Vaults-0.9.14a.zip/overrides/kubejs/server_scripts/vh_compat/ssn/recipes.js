onEvent("recipes", event => {
    Ingredient.of('@storagenetwork').itemIds.forEach(id => {
        event.remove({ 'output': `${id}` })
    })
})