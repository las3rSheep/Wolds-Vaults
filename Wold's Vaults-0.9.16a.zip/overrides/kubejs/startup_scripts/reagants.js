
onEvent('item.registry', event => {
    event.create('the_vault:gem_reagent_ashium').group('the_vault').displayName('Gem Reagent: Ashium')
    event.create('the_vault:gem_reagent_bomignite').group('the_vault').displayName('Gem Reagent: Bomignite')
    event.create('the_vault:gem_reagent_gorginite').group('the_vault').displayName('Gem Reagent: Gorginite')
    event.create('the_vault:gem_reagent_iskallium').group('the_vault').displayName('Gem Reagent: Iskallium')
    event.create('the_vault:gem_reagent_petzanite').group('the_vault').displayName('Gem Reagent: Petezanite')
    event.create('the_vault:gem_reagent_sparkletine').group('the_vault').displayName('Gem Reagent: Sparkletine')
    event.create('the_vault:gem_reagent_tubium').group('the_vault').displayName('Gem Reagent: Tubium')
    event.create('the_vault:gem_reagent_upaline').group('the_vault').displayName('Gem Reagent: Upaline')
    event.create('the_vault:gem_reagent_xenium').group('the_vault').displayName('Gem Reagent: Xeenium')
})
