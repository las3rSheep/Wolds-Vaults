onEvent('jei.hide.items', event => {
    event.hide('toms_storage:ts.open_crate')
})