onEvent('item.tooltip', tooltip => {
    tooltip.add('lightmanscurrency:wallet_copper', Text.green('Soulbound'))
    tooltip.add('lightmanscurrency:wallet_iron', Text.green('Soulbound'))
    tooltip.add('lightmanscurrency:wallet_gold', Text.green('Soulbound'))
    tooltip.add('lightmanscurrency:wallet_emerald', Text.green('Soulbound'))
    tooltip.add('lightmanscurrency:wallet_diamond', Text.green('Soulbound'))
    tooltip.add('lightmanscurrency:wallet_netherite', Text.green('Soulbound'))
})